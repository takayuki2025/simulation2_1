<?php

namespace Phiki\Exceptions;

use InvalidArgumentException;

class InvalidThemeException extends InvalidArgumentException
{
    //
}
