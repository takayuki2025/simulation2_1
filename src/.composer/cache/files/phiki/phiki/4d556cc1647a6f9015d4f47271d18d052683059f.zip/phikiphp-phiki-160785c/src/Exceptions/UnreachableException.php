<?php

namespace Phiki\Exceptions;

use Exception;

class UnreachableException extends Exception
{
    //
}
